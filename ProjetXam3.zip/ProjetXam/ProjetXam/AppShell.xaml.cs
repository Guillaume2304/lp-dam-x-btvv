﻿using System;
using Xamarin.Forms;

namespace ProjetXam
{
    public partial class AppShell : Shell
    {
        public AppShell()
        {
            InitializeComponent();
        }
    }
}